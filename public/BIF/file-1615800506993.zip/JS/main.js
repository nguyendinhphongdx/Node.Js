// console.log("hello")
function allLongestStrings(inputArray) {
    console.log(inputArray)
    let maxSize = Math.max(...inputArray.map(x => x.length));
    console.log(...inputArray.map(x => x.length))
    console.log(maxSize)
    return inputArray.filter(x => x.length === maxSize);

}


// const allLongestStrings = (inputArray) =>{
//     let maxSize = Math.max(...inputArray.map(x => x.length));
    
//     debugger
//     return inputArray.filter(x => x.length === maxSize);
// }

console.log(allLongestStrings(["abc", 
"eeee", 
"abcd", 
"dcd"]))

// function cha(){
//     let x = 10 ;
//     return function con(p){
//         x++;
//         return x+ p;
//     }
// }
// console.log(cha()) // tra hai ham
// console.log(cha()(1)) // tra lai 12 
// let bien = cha();
// console.log(bien)

// function truoc(callback){
//     setTimeout(function(){
//         console.log("task1")
//         callback()
//     },2000)
// }
// function sau(){
//     setTimeout(function(){
//         console.log("task2")
//     },1000)
// }

// console.log("task3")

// truoc(sau)